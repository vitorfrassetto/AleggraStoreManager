function setaCampos(me) {
    console.log(me)
}